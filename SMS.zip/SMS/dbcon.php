
<?php 
//create connection
$conn = mysqli_connect('sql207.epizy.com','epiz_31846439','3QXe8CJW7feb','epiz_31846439_SMS');

//check connection

if (!$conn) {
    echo "connection failed: " . mysqli_connect_error()."<br>";
    echo "connection error no: " . mysqli_connect_errno();

} else {
   // echo "connected successfuly";
}



 ?>